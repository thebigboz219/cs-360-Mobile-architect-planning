package com.example.jacobmcpherson_weight_tracker2;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddWeight extends AppCompatActivity {
    private EditText mUserWeight;
    private EditText mUserDate;
    private ImageButton saveButton;
    private ImageButton cancelButton;
    public static final String EXTRA_WEIGHT = "UserWeight";
    public static final String EXTRA_DATE = "UserDate";
    public static final String EXTRA_PURPOSE = "ButtonClicked";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight);
        mUserWeight = findViewById(R.id.entered_weight);
        mUserDate = findViewById(R.id.entered_date);
        saveButton = (ImageButton)findViewById(R.id.add_button);
        cancelButton = (ImageButton)findViewById(R.id.no_button);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int buttonPurpose = 1;
                int inputWeight = Integer.parseInt(mUserWeight.getText().toString());
                if (inputWeight < 1) {
                    Toast.makeText(AddWeight.this, "Please enter a valid Weight.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String inputDate = mUserDate.getText().toString();
                if (inputDate.equals(null)) {
                    Toast.makeText(AddWeight.this, "Please enter a valid Date.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent();
                intent.putExtra(EXTRA_WEIGHT, inputWeight);
                intent.putExtra(EXTRA_DATE, inputDate);
                intent.putExtra(EXTRA_PURPOSE, buttonPurpose);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                setResult(RESULT_CANCELED, intent);
                finish();
            }
        });
    }


}
