package com.example.jacobmcpherson_weight_tracker2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class EditWeight extends AppCompatActivity {

    private EditText mUserWeight;
    private EditText mUserDate;
    private ImageButton saveButton;
    private ImageButton cancelButton;
    public static final String EXTRA_WEIGHT = "UserWeight";
    public static final String EXTRA_DATE = "UserDate";
    public static final String EXTRA_PURPOSE = "ButtonClicked";
    public static final String EXTRA_POSITION = "ItemPosition";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight);
        mUserWeight = findViewById(R.id.changed_weight);
        mUserDate = findViewById(R.id.changed_date);
        saveButton = (ImageButton)findViewById(R.id.confirm_change);
        cancelButton = (ImageButton)findViewById(R.id.cancel_change);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int buttonPurpose = 2;
                int position = getIntent().getIntExtra("POSITION", 0);
                int inputWeight = Integer.parseInt(mUserWeight.getText().toString());
                if (inputWeight < 1) {
                    Toast.makeText(EditWeight.this, "Please enter a valid Weight.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String inputDate = mUserDate.getText().toString();
                if (inputDate.equals(null)) {
                    Toast.makeText(EditWeight.this, "Please enter a valid Date.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent();
                intent.putExtra(EXTRA_WEIGHT, inputWeight);
                intent.putExtra(EXTRA_DATE, inputDate);
                intent.putExtra(EXTRA_PURPOSE, buttonPurpose);
                intent.putExtra(EXTRA_POSITION, position);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                setResult(RESULT_CANCELED, intent);
                finish();
            }
        });
    }
}