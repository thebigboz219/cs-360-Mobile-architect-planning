package com.example.jacobmcpherson_weight_tracker2.LoginRepository;

import androidx.annotation.NonNull;

public class Account {

    private String mUsername;
    private String mPassword;

    public Account(@NonNull String name, @NonNull String pass) {
        mUsername = name;
        mPassword = pass;
    }

    public String getUsername() {
        return mUsername;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String pass) {
        mPassword = pass;
    }
}
