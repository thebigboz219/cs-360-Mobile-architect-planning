package com.example.jacobmcpherson_weight_tracker2.LoginRepository;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LoginRepository {

    private static LoginRepository instance;
    private final List<Account> mAccountList;

    public static LoginRepository getInstance(Context context) {
        if (instance == null) {
            instance = new LoginRepository(context);
        }
        return instance;
    }

    private LoginRepository(Context context) {
        mAccountList = new ArrayList<>();

        addBaseLogins();
    }

    private void addBaseLogins() {
        Account account = new Account("bob123", "Mcguffin");
        addAccount(account);

        account = new Account("Bl00m43", "Wilting");
        addAccount(account);

        account = new Account("CodeJockey", "N3v3r$urr3nd3r");
        addAccount(account);
    }

    public void addAccount(Account account) {
        mAccountList.add(account);
    }

    public Account getAccount(String accountName) {
        for (Account account: mAccountList) {
            if (Objects.equals(account.getUsername(), accountName)) {
                return account;
            }
        }
        return null;
    }

    public List<Account> getAccounts() {
        return mAccountList;
    }

    public void setPassword(String accountName, String accountPass) {
        for (Account account: mAccountList) {
            if (Objects.equals(account.getUsername(), accountName)) {
                account.setPassword(accountPass);
                return;
            }
        }

    }
}
