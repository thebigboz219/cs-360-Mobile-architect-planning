package com.example.jacobmcpherson_weight_tracker2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.jacobmcpherson_weight_tracker2.LoginRepository.Account;
import com.example.jacobmcpherson_weight_tracker2.LoginRepository.LoginRepository;
import com.example.jacobmcpherson_weight_tracker2.recyclerview.weightRecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private LoginRepository mLoginRepo;
    private List<Account> mAccountList;
    private EditText mUsernameView;
    private EditText mPasswordView;
    private ImageView mAppImage;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mLoginRepo = LoginRepository.getInstance(getApplication().getApplicationContext());
        mAccountList = mLoginRepo.getAccounts();
        mUsernameView = findViewById(R.id.username_input);
        mPasswordView = findViewById(R.id.password_input);
        mAppImage = findViewById(R.id.App_profile);

        mAppImage.setImageResource(R.drawable.cartoon_caveman_hammer_chisel_next_to_blank_rock_31718619);
    }

    public void verifyCredentials(View view) {
        if (mUsernameView.getText().toString().length() < 1 || mPasswordView.getText().toString().length() < 1) {
            Toast.makeText(MainActivity.this, "Input fields can not be empty.", Toast.LENGTH_SHORT).show();
            return;
        }
        for (Account account: mAccountList) {
            if (mUsernameView.getText().toString().equals(account.getUsername())) {
                if (mPasswordView.getText().toString().equals(account.getPassword())) {
                    Intent intent = new Intent(this, weightRecyclerView.class);
                    startActivity(intent);
                    return;
                }
                else {
                    Toast.makeText(MainActivity.this, "Incorrect password, please try again.", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
        Toast.makeText(MainActivity.this, "No account exists with those credentials.", Toast.LENGTH_SHORT).show();
    }

    // registerCredentials currently will check the login repository for any instance of a newly entered username, however I
    // was unable to setup the memory database in time for turn in.
    public void registerCredentials(View view) {
        if (mUsernameView.getText().toString().length() < 1 || mPasswordView.getText().toString().length() < 1) {
            Toast.makeText(MainActivity.this, "Input fields can not be empty.", Toast.LENGTH_SHORT).show();
            return;
        }
        for (Account account: mAccountList) {
            if (mUsernameView.getText().toString().equals(account.getUsername())) {
                Toast.makeText(MainActivity.this, "Username is already in use.", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        Account userAccount = new Account(mUsernameView.getText().toString(), mPasswordView.getText().toString());
        mLoginRepo.addAccount(userAccount);
    }
}