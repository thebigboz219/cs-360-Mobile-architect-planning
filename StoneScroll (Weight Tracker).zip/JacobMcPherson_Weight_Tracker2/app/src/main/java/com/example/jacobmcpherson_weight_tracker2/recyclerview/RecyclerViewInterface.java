package com.example.jacobmcpherson_weight_tracker2.recyclerview;

public interface RecyclerViewInterface {
    void onItemClick(int position);
    void onDeleteClick(int position);
}
