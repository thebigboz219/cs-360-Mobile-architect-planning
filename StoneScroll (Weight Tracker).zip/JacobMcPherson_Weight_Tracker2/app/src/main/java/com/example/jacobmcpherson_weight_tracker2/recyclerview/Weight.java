package com.example.jacobmcpherson_weight_tracker2.recyclerview;

import androidx.annotation.NonNull;

import java.time.LocalDate;

public class Weight {
    private int weight;
    private String date;

    public Weight(@NonNull int cWeight, String cDate) {
        weight = cWeight;
        date = cDate;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void setDate(String date) { this.date = date; }

    public int getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }
}

