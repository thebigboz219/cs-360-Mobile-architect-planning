package com.example.jacobmcpherson_weight_tracker2.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.jacobmcpherson_weight_tracker2.R;

import java.util.ArrayList;



public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightHolder> {
    private final RecyclerViewInterface recyclerViewInterface;
    private Context context;
    private ArrayList<Weight> weights;

    public WeightAdapter(Context context, ArrayList<Weight> weights, RecyclerViewInterface recyclerViewInterface) {
        this.context = context;
        this.weights = weights;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public WeightHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_weight, parent, false);

        return new WeightHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightAdapter.WeightHolder holder, int position) {

        Weight weight = weights.get(position);
        holder.bind(weight);
    }

    @Override
    public int getItemCount() {
        return weights.size();
    }

    static class WeightHolder extends RecyclerView.ViewHolder{

        private WeightAdapter adapter;
        private TextView weightView, dateView;
        private Button deleteButton;

        public WeightHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);
            weightView = itemView.findViewById(R.id.weight_entry);
            dateView = itemView.findViewById(R.id.date_entry);
            deleteButton = itemView.findViewById(R.id.delete_row);

            weightView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (recyclerViewInterface != null) {
                        int pos = getAbsoluteAdapterPosition();

                        if (pos != RecyclerView.NO_POSITION) {
                            recyclerViewInterface.onItemClick(pos);
                        }
                    }
                }
            });

            dateView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (recyclerViewInterface != null) {
                        int pos = getAbsoluteAdapterPosition();

                        if (pos != RecyclerView.NO_POSITION) {
                            recyclerViewInterface.onItemClick(pos);
                        }
                    }
                }
            });

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (recyclerViewInterface != null) {
                        int pos = getAbsoluteAdapterPosition();

                        if (pos != RecyclerView.NO_POSITION) {
                            recyclerViewInterface.onDeleteClick(pos);
                        }
                    }
                }
            });
        }

        void bind(Weight weight) {
            weightView.setText((String.valueOf(weight.getWeight())));
            dateView.setText(weight.getDate());
        }
    }
}
