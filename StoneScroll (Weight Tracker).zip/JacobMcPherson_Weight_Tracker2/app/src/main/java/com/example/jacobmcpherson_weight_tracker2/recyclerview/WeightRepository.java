package com.example.jacobmcpherson_weight_tracker2.recyclerview;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class WeightRepository {

    private static WeightRepository instance;
    private final ArrayList<Weight> mWeightList;

    public static WeightRepository getInstance(Context context) {
        if (instance == null) {
            instance = new WeightRepository(context);
        }
        return instance;
    }

    private WeightRepository(Context context) {
        mWeightList = new ArrayList<>();

        addBaseData();
    }

    private void addBaseData() {
        Weight weight = new Weight(140, "10/20/2020");
        addWeightLog(weight);

        weight = new Weight(200, "11/22/2020");
        addWeightLog(weight);

        weight = new Weight(179, "12/25/2020");
        addWeightLog(weight);
    }

    public void addWeightLog(Weight weight) {
        mWeightList.add(weight);
    }

    public Weight getWeightLog(int mWeight) {
        for (Weight weight: mWeightList) {
            if (weight.getWeight() == mWeight) {
                return weight;
            }
        }
        return null;
    }

    public ArrayList<Weight> getWeights() { return mWeightList; }

    public void setWeight(int mWeight, String mDate) {
        for (Weight weight: mWeightList) {
            if (Objects.equals(weight.getDate(), mDate)) {
                weight.setWeight(mWeight);
                return;
            }
        }
    }
}
