package com.example.jacobmcpherson_weight_tracker2.recyclerview;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.jacobmcpherson_weight_tracker2.AddWeight;
import com.example.jacobmcpherson_weight_tracker2.EditWeight;
import com.example.jacobmcpherson_weight_tracker2.R;
import com.example.jacobmcpherson_weight_tracker2.SettingsActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class weightRecyclerView extends AppCompatActivity implements RecyclerViewInterface{

    RecyclerView weight_recycler;

    private WeightAdapter adapter;
    private WeightRepository weightRepo;
    private ArrayList<Weight> weightArrayList;


    // I was able to get the entire functionality of the weight repository and recyclerview working, however
    // I was still unable to get the memory database in place to remember inputs after app closure.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_recycler_view);
        Toolbar myToolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(myToolbar);

        FloatingActionButton addButton = findViewById(R.id.weight_addition);
        weightRepo = WeightRepository.getInstance(getApplication().getApplicationContext());
        weight_recycler = findViewById(R.id.weight_recy);

        weight_recycler.setLayoutManager(new LinearLayoutManager(this));
        weightArrayList = weightRepo.getWeights();
        adapter = new WeightAdapter(this, weightArrayList, this);
        weight_recycler.setAdapter(adapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(weightRecyclerView.this, AddWeight.class);
                mWeightResultLauncher.launch(intent);
            }
        });
    }

    ActivityResultLauncher<Intent> mWeightResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            int clickPurpose = data.getIntExtra("ButtonClicked", 0);
                            if (clickPurpose == 1) {
                                int newWeight = data.getIntExtra(AddWeight.EXTRA_WEIGHT, 0);
                                String newDate = data.getStringExtra(AddWeight.EXTRA_DATE);
                                Weight newEntry = new Weight(newWeight, newDate);
                                weightRepo.addWeightLog(newEntry);
                                weightArrayList = weightRepo.getWeights();
                            }
                            if (clickPurpose == 2) {
                                int changedWeight = data.getIntExtra(EditWeight.EXTRA_WEIGHT, 0);
                                String changedDate = data.getStringExtra(EditWeight.EXTRA_DATE);
                                int changePosition = data.getIntExtra(EditWeight.EXTRA_POSITION, 0);
                                weightArrayList.get(changePosition).setWeight(changedWeight);
                                weightArrayList.get(changePosition).setDate(changedDate);
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                }
            }
    );

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(weightRecyclerView.this, EditWeight.class);

        intent.putExtra("WEIGHT", weightArrayList.get(position).getWeight());
        intent.putExtra("DATE", weightArrayList.get(position).getDate());
        intent.putExtra("POSITION", position);

        mWeightResultLauncher.launch(intent);
    }

    @Override
    public void onDeleteClick(int position) {
        weightArrayList.remove(position);
        adapter.notifyItemRemoved(position);
    }
}